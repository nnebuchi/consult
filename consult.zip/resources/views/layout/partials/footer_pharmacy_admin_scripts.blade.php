	<!-- jQuery -->
	<script src="../assets_pharmacy/js/jquery-3.2.1.min.js"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="../assets_pharmacy/js/popper.min.js"></script>
        <script src="../assets_pharmacy/js/bootstrap.min.js"></script>
		
		<!-- Slimscroll JS -->
        <script src="../assets_pharmacy/plugins/slimscroll/jquery.slimscroll.min.js"></script>
		@if(Route::is(['pagee','pagees']))
		<script src="../assets_pharmacy/plugins/raphael/raphael.min.js"></script>    
		<script src="../assets_pharmacy/plugins/morris/morris.min.js"></script>  
		<script src="../assets_pharmacy/js/chart.morris.js"></script>
		@endif
		<!-- Form Validation JS -->
        <script src="../assets_pharmacy/js/form-validation.js"></script>
		<!-- Mask JS -->
		<script src="../assets_pharmacy/js/jquery.maskedinput.min.js"></script>
        <script src="../assets_pharmacy/js/mask.js"></script>
			<!-- Select2 JS -->
			<script src="../assets_pharmacy/js/select2.min.js"></script>
		
			<!-- Datetimepicker JS -->
			<script src="../assets_pharmacy/js/moment.min.js"></script>
		<script src="../assets_pharmacy/js/bootstrap-datetimepicker.min.js"></script>
		
		<!-- Full Calendar JS -->
        <script src="../assets_pharmacy/js/jquery-ui.min.js"></script>
        <script src="../assets_pharmacy/plugins/fullcalendar/fullcalendar.min.js"></script>
        <script src="../assets_pharmacy/plugins/fullcalendar/jquery.fullcalendar.js"></script>
		<!-- Datatables JS -->
		<script src="../assets_pharmacy/plugins/datatables/jquery.dataTables.min.js"></script>
		<script src="../assets_pharmacy/plugins/datatables/datatables.min.js"></script>	
		<!-- Custom JS -->
		<script  src="../assets_pharmacy/js/script.js"></script>